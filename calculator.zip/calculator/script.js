// Buttons ARRAY
const buttons = ['(', ')', '9', '8', '7', '6', '5', '4', '3', '2', '1', '0', '.', '*', '-', '+', '/'];

// Gobal Variables
const btnContainer = document.querySelector('.btn-container');
const result = document.getElementById('result');

// Event Listener on click buttons
btnContainer.addEventListener('click', (e) => {
	// Store the target value in varible
	const pressBtn = e.target.value;
	for(let i = 0; i < buttons.length; i++) {
		if(buttons[i] == pressBtn) {
			result.value += buttons[i];
			break;
		} 
		else if(pressBtn == '=') {
			const equation = result.value;
			// Check the equation is empty or not
			if(equation === '') {
				alert('Please enter the equation');
				break;
			} else {
				// Solve the equation
				solve(equation);
				break;
			}
		} 
		else if(pressBtn == 'C') clear();
	}
});

// Solve function
function solve(equation) {
	const answer = eval(equation);

	// Assign the answer
	result.value = answer;
}

// Clear Function
function clear() {
	result.value = '';
}




















